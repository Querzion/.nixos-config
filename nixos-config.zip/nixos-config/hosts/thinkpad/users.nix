{ config, pkgs, ... }:

{
  users.users.slisk = {
    isNormalUser = true;
    description  = "Slisk Lindqvist";
    extraGroups  = [ "networkmanager" "wheel" "bluetooth" "input" "docker" ];
    shell        = pkgs.bash;
  };
}
