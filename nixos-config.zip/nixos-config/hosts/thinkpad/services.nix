{ config, pkgs, ... }:

{
  services.printing.enable = false;

  services.pulseaudio.enable = false;

  services.pipewire = {
    enable = true;
    pulse.enable = true;
    alsa.enable = true;
    alsa.support32Bit = true;
    jack.enable = true;
  };

  # Keyboard layout - Swedish Dvorak
  services.xserver.xkb = {
    layout  = "se";
    variant = "dvorak";
  };

  security.rtkit.enable = true;
}
